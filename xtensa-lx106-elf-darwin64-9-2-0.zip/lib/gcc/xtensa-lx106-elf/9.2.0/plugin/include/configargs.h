/* Generated automatically. */
static const char configuration_arguments[] = "/workdir/repo/gcc-gnu/configure --prefix=/workdir/xtensa-lx106-elf.osx --build=x86_64-linux-gnu --host=x86_64-apple-darwin14 --target=xtensa-lx106-elf --disable-shared --with-newlib --enable-threads=no --disable-__cxa_atexit --disable-libgomp --disable-libmudflap --disable-nls --disable-multilib --disable-bootstrap --enable-languages=c,c++ --enable-lto --enable-static=yes --disable-libstdcxx-verbose";
static const char thread_model[] = "single";

static const struct {
  const char *name, *value;
} configure_default_options[] = { { NULL, NULL} };
